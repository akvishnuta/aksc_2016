<?php
   define('DB_SERVER', 'aksc16.com');
   define('DB_USERNAME', 'ieeekera_aksc');
   define('DB_PASSWORD', 'Career@007');
   define('DB_DATABASE', 'db_students');
   $db = mysqli_connect(DB_SERVER,DB_USERNAME,DB_PASSWORD,DB_DATABASE);
?>